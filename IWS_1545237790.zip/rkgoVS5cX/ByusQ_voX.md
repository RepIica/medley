# VScode
`cmd shift H` to search for relative file paths
`cmd enter`for new line
`cmd shft enter`for new line above
`alt shft down/up`for duplicate line