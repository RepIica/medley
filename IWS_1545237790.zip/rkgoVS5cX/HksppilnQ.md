# to do
### general questions/concerns
- comps should have 1 or 2 responsive versions 
  - convey how unique elements should adapt to larger and smaller screens (larger screens, small height laptop screens
- montreux 
  - repetitive css classes 
  - every view page wet css despite similar layouts
  - 1 layout change needed on every scss file
  - deviate from comp font properties
- 
## Updates
refactor DayPickerInput.js 
- include prop for `showOverlay`(already on `<DayPickerInput />` from npm component
- rename consistent name
- delete DatePickerInput.js
boilerplate:
- `if (!this.props.formState.success)`
- nav widget with active classes, non active links when already on current page
  - styled component?
  - mobile nav that toggles slideout menu
cms:
- User is logged out after timing out, saving doesn't work but also doesn't give any indication user is logged out
  - check if user is logged on when saving
  - prompt to log back in if not logged in

Montreux:
- Need
  - amenities icon svgs
  - button hover states
  - footer
    - font
    - icon sizes
  - Apartments view
    - content width mixin
    - texg-lg mixin
  - Floor-plans view 
    - styling, transitions
    - storage and type filters
  - mobile
- Extra
  - desktop subnav transition
    - conditional class instead of conditional render (NavItem.js)
  - amenities accordion open close icon animation
## Review
JS array difference https://codepen.io/jvgraph/pen/VEOBOQ?editors=0012
- filter
- reduce
- !includes