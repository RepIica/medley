# CMS API general notes
sitemap paths connect to view component automatically with same name as **template name**
template names always name lowercase
