# boilerplate
admin/ contains the cms admin application. Commands for running and building the admin app can be found in admin/package.json
- pulls version 1 admin app by default
- newer versions fix a few bugs (currently on 1.04)
- `npm run downloadAdmin` to clone the latest admin app into the project
  - more info on https://github.com/ideawork/iws-boilerplate#init-admin-app

Dev site can be ideaworkwidgets or ideaworkdevelopment
can verify dev site in package.json

change package.json in public folder of boilerplate to 
`"DEV_SITE": "http://ariawinebar.ideaworkwidgets.com/",`
when repo is built and deployed

test form submission in dev site by checking response in network dev tools

![Image](https://www.dropbox.com/s/yyj19hl392r6v9a/Skzi4Hc57_SyEJghl2Q.png?dl=1)

### onClick events
- `onClick={this.props.clickHandler}` on outtermost JSX element
- `static propTypes = { onClick: PropTypes.func }`












