# new projects
https://github.com/ideawork/iws-docs/blob/master/new-project-checklist.md

- setup git hooks (fix my git account permissions)
  - https://github.com/ideawork/iws-docs/blob/master/new-project-checklist.md#Git-hooks-Setup
- change package.json in public folder of boilerplate to :
  - `"DEV_SITE": "http://ariawinebar.ideaworkwidgets.com/",`when repo is built and deployed
- new scss files in global need to be imported in main.scss
- add fonts
  - convert fonts to webfonts
  - place woffs in fonts directory
  - add to _fonts.scss in global directory
    - create mixins (optional)
- add scss variables for colors

### Illustrator SVGs-
1. double click path
1. CMD + X
1. double click outside canvas
1. CMD + F (paste in place)
1. repeat for 1-4 for all
1. to delete background layer/border thingy double click corner and delete

### Navigation
- get nav items from CMS with `context.content.ChildrenById(parentId).filter().map()`, example below
- exclude pages from nav in CMS by unchecking 'DEV Stuff' tab > Show in Nav
- optional--> check for active nav items by comparing `location.pathname` and `item.path`
```javascript
import NavItem from "./NavItem";
import Booking from "./Booking";
import SVG from "../../widgets/Svg";
export default class Navigation extends React.Component {
	static contextTypes = {
		content: PropTypes.object,
		windowWidth: PropTypes.number
	};
	constructor(props, context) {
		super(props, context);
		this.parent = context.content.byTemplate("location_home");
	}
	renderNav() {
		let parentId;
		if (window.location.pathname.includes("/aria-west-village")) {
			parentId = this.parent[0].id;
		} else {
			parentId = this.parent[1].id;
		}
		return this.context.content
			.childrenById(parentId)
			.filter(item => item.showinnav)
			.map(item => <NavItem item={item} key={item.id} />);
	}
	render() {
		const { windowWidth } = this.context;
		return (
			<div className={`navigation`}>
				<div className="navigation--container">
					<div className="decor for--nav">{SVG.decor}</div>
					<nav className="menu">
						<ul className="menu--items">{this.renderNav()}</ul>
					</nav>
					{windowWidth < 1001 && (
						<Booking text="BOOK A TABLE" classNames="mobile" />
					)}
				</div>
			</div>
		);
	}
}
```


Optional
- page redirect for directories to redirect to first subdirectory, eg. in aria-nyc: /about --> /about/concept
```javascript
import { Redirect } from "react-router";
export default class RedirectPageToChild extends React.Component {
	static propTypes = {
		page: PropTypes.object
	};
	static contextTypes = {
		content: PropTypes.object
	};
	constructor(props, context) {
		super(props, context);
		this.children = context.content.childrenById(props.page.id);
	}
	render() {
		console.log(this.children);
		return <Redirect to={this.children[0].path} />;
	}
}
```
