# CMS API context
- Get data from other templates with context instead of props and refer to it with content.byTemplate('templateName')
e.g.-
```javascript
export default class About extends React.Component {
	static propTypes = {
		page: PropTypes.object
	};

	static contextTypes = {
		content: PropTypes.object
	};

	constructor(props, context) {
		super(props, context);
	}

	render() {
		const aboutPage = content.byTemplate("about");
		debugger;
		return (
			<section className="concept-section">
				<h1>The Concept</h1>
				<p>LoremIpsums sodjosao ammascmasm</p>
			</section>
		);
	}
}

```

- add to content with `getChildContext` method and `childContextTypes` static object
- more info at https://reactjs.org/docs/legacy-context.html
eg
```javascript
import appContextProvider from "containers/appContextProvider";

class App extends React.Component {
	static contextTypes = {
		content: PropTypes.object
	};
	static childContextTypes = {
		windowWidth: PropTypes.number
	};

	getChildContext = () => ({
		windowWidth: this.state.windowWidth
	});
	constructor(props, context) {
		super(props, context);
		this.state = {
			accessible: false,
			windowWidth: window.innerWidth
		};
		this.routes = this.buildRoutes();
		this.pageChangeRoutine(props, context);
	}

	componentDidMount() {
		window.addEventListener("resize", this.handleResize);
	}
	componentWillUnmount() {
		window.removeEventListener("resize", this.handleResize);
	}
	handleResize = () => {
		this.setState({ windowWidth: window.innerWidth });
	};
	
	// ... rest of App.js
}
```






