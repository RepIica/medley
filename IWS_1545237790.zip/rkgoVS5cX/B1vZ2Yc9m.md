# git workflow

from development, deployed build for development,  pushed to master for Kent to push to production
older version-
```bash
npm run build
gaa
gcmsg
ggpush
git push dev development # is for Gitblit
```

push to dev-
```bash
npm run build
gaa
gcmsg
ggpush
```
`npm run build:deploy` shortcut